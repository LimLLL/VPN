import{W as a,aZ as m}from"./index-Dty2i_OM.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
