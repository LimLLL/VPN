import{d as t,bv as r}from"./index-Dty2i_OM.js";const o=({children:e})=>t(r,{get children(){return[e," - MetaCubeXD"]}});export{o as D};
